<?php
include 'koneksi.php';

session_start();

// Mengambil data Login
$iduser = $_POST['iduser'];
$namauser =$_POST['namauser'];

// Mengambil data dari tabel users
$query = mysqli_query($conn, "SELECT * FROM user WHERE iduser = '$iduser' AND namauser = '$namauser'");
// Menghitung jumlah data
$cek = mysqli_num_rows($query);

// Jika User ditemukan lebih dari 1 maka user di temukann
if ($cek > 0) {
    $qry = mysqli_fetch_array($query);
    $_SESSION['iduser'] = $qry['iduser'];
    $_SESSION['namauser'] = $qry['namauser'];
    $_SESSION['level'] = $qry['level'];

    header("location:log.php");
} else {
    header("location:login.php?pesan=gagal");
}
