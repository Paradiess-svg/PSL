<?php
include '../koneksi.php';
function tambah_data($data, $files){

    $idmenu = $data['idmenu'];
    $namamenu = $data['namamenu'];
    $status = $data['status'];
    $harga = $data['harga'];


    $query = "INSERT INTO menu VALUES('$idmenu', '$namamenu', 'default.jpg' , '$status', '$harga')";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function ubah_data($data, $files){
    $idmenu = $data['idmenu'];
    $namamenu = $data['namamenu'];
    $status = $data['status'];
    $harga = $data['harga'];

    $queryshow = "SELECT * FROM menu WHERE idmenu = '$idmenu';";
    $sqlshow = mysqli_query($GLOBALS['conn'], $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    if($files['foto']['name'] ==""){
        $foto = $result['foto'];
    }else{
        $split = explode('.',$files['foto']['name']);
        $ekstensi = $split[count($split)-1];

        $foto = $result['idmenu'].'.'.$ekstensi;
        move_uploaded_file($files['foto']['tmp_name'], '../imgMenu/'.$foto);
    }
    
    $query = "UPDATE menu SET idmenu='$idmenu', foto = '$foto' WHERE idmenu='$idmenu';";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function hapus_data($data){
    $idmenu = $data['hapus'];

    $queryshow = "SELECT * FROM menu WHERE idmenu = '$idmenu';";
    $sqlshow = mysqli_query($GLOBALS['conn'] , $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    unlink("img/".$result['foto']);

    $query="DELETE FROM menu WHERE idmenu = '$idmenu' ;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;

}

?>