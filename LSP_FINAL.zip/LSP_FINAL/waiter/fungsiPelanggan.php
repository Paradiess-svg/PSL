<?php
include '../koneksi.php';
function tambah_data($data, $files){

    $idpelanggan = $data['idpelanggan'];
    $namapelanggan = $data['namapelanggan'];
    $jeniskelamin = $data['jeniskelamin'];
    $nohp = $data['nohp'];
    $alamat = $data['alamat'];

    $query = "INSERT INTO pelanggan VALUES('$idpelanggan', '$namapelanggan', '$jeniskelamin', '$nohp', '$alamat')";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function ubah_data($data, $files){
    $idpelanggan = $data['idpelanggan'];
    $namapelanggan = $data['namapelanggan'];
    $jeniskelamin = $data['jeniskelamin'];
    $nohp = $data['nohp'];
    $alamat = $data['alamat'];

    $queryshow = "SELECT * FROM pelanggan WHERE idpelanggan = '$idpelanggan';";
    $sqlshow = mysqli_query($GLOBALS['conn'], $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    
    $query = "UPDATE pelanggan SET idpelanggan='$idpelanggan', namapelanggan = '$namapelanggan', jeniskelamin = '$jeniskelamin', nohp = '$nohp', alamat = '$alamat' WHERE idpelanggan='$idpelanggan';";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function hapus_data($data){
    $idpelanggan = $data['hapus'];

    $queryshow = "SELECT * FROM pelanggan WHERE idpelanggan = '$idpelanggan';";
    $sqlshow = mysqli_query($GLOBALS['conn'] , $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    unlink("img/".$result['foto']);

    $query="DELETE FROM pelanggan WHERE idpelanggan = '$idpelanggan' ;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;

}

?>