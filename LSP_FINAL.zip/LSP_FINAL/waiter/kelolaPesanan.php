<!DOCTYPE html>

<?php
include '../koneksi.php';
session_start();


$idpesanan = '';
$idmenu = '';
$idpelanggan ='';
$jumlah = '';
$iduser = '';
$kodebill = '';

if (isset($_GET['ubah'])) {
    $idpesanan = $_GET['ubah'];

    $query = "SELECT * FROM pesanan WHERE idpesanan = '$idpesanan';";
    $sql = mysqli_query($conn, $query);

    $result = mysqli_fetch_assoc($sql);

    $idpesanan = $result ['idpesanan'];
    $idmenu = $result ['idmenu'];
    $idpelanggan = $result ['idpelanggan'];
    $jumlah = $result ['jumlah'];
    $iduser = $result ['iduser'];
    $kodebill = $result ['kodebill'];


    //var_dump($result);

    //die();
}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../datatables/datatables.css">
    <script src="../datatables/datatables.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>


    <link rel="apple-touch-icon" sizes="180x180" href="asset/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="asset/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="asset/favicon-16x16.png">
<link rel="manifest" href="asset/site.webmanifest">

    <title>Waiter Entri pesanan</title>
</head>

<body>
    <nav class="navbar bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                Table Service
            </a>
        </div>
    </nav>
    <div class="container">
        <h1 class="mt-3">Waiter Entri pesanan</h1>

        <div class="container">
            <form method="post" action="prosesPesanan.php" enctype="multipart/form-data">
                <input type="hidden" value="<?php echo $idpesanan?>" name="idpesanan">
                <div class="mb-3 row">
                    <label for="idpesanan" class="col-sm-2 col-form-label">Nomor pesanan</label>
                    <div class="col-sm-10">
                        <?php if (isset($_GET['ubah'])) { ?>
                            <input required type="text" name="idpesanan" class="form-control" id="idpesanan" value="<?php echo $idpesanan ?>" disabled>
                        <?php
                        } else{
                        ?>
                        <input required type="text" name="idpesanan" class="form-control" id="idpesanan" placeholder="Ex: 12" value="<?php echo $idpesanan ?>">
                    <?php } ?>
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="nama" class="col-sm-2 col-form-label">idmenu</label>
                    <div class="col-sm-10">
                        <input required type="text" name="idmenu" class="form-control" id="nama" placeholder="Ex: 321" value="<?php echo $idmenu ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                <label for="idpelanggan" class="col-sm-2 col-form-label">idpelanggan</label>
                    <div class="col-sm-10">
                        <input required type="text" name="idpelanggan" class="form-control" id="idpelanggan" placeholder="Ex: 102" value="<?php echo $idpelanggan ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                <label for="jumlah" class="col-sm-2 col-form-label">jumlah</label>
                    <div class="col-sm-10">
                        <input required type="text" name="jumlah" class="form-control" id="jumlah" placeholder="Ex: 2" value="<?php echo $jumlah?>">
                    </div>
                </div>

                <div class="mb-3 row">
                <label for="iduser" class="col-sm-2 col-form-label">iduser</label>
                    <div class="col-sm-10">
                        <input required type="text" name="iduser" class="form-control" id="iduser" placeholder="Ex: 3001" value="<?php echo $iduser ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                <label for="kodebill" class="col-sm-2 col-form-label">kodebill</label>
                    <div class="col-sm-10">
                        <input required type="text" name="kodebill" class="form-control" id="kodebill" placeholder="Ex: 101A" value="<?php echo $kodebill ?>">
                    </div>
                </div>

                <div class="mb-3 row mt-3">
                    <div class="col">
                        <?php
                        if (isset($_GET['ubah'])) {
                        ?>
                            <button type="submit" name="aksi" value="edit" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Simpan Perubahan</button>
                        <?php
                        } else {
                        ?>
                            <button type="submit" name="aksi" value="add" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Tambah</button>
                        <?php
                        }
                        ?>
                        <a href="indexPesanan.php" type="button" class="btn btn-danger"><i class="fa fa-reply mx-1" aria-hidden="true"></i>Batal</a>
                    </div>
            </form>
        </div>



        <h6>Hello mom</h6>
</body>

</html>