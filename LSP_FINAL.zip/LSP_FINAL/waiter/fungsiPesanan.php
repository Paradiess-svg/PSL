<?php
include '../koneksi.php';
function tambah_data($data, $files){

    $idpesanan = $data['idpesanan'];
    $idmenu = $data['idmenu'];
    $idpelanggan = $data['idpelanggan'];
    $jumlah = $data['jumlah'];
    $iduser = $data['iduser'];
    $kodebill = $data['kodebill'];
    
    $query = "INSERT INTO pesanan VALUES('$idpesanan', '$idmenu', '$idpelanggan', '$jumlah','$iduser','$kodebill')";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function ubah_data($data, $files){

    $idpesanan = $data['idpesanan'];
    $idmenu = $data['idmenu'];
    $idpelanggan = $data['idpelanggan'];
    $jumlah = $data['jumlah'];
    $iduser = $data['iduser'];
    $kodebill = $data['kodebill'];

    $queryshow = "SELECT * FROM pesanan WHERE idpesanan = '$idpesanan';";
    $sqlshow = mysqli_query($GLOBALS['conn'], $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    
    $query = "UPDATE pesanan SET idpesanan='$idpesanan', idmenu = '$idmenu', idpelanggan = '$idpelanggan', jumlah = '$jumlah', iduser = '$iduser', kodebill = '$kodebill' WHERE idpesanan='$idpesanan';";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;
}

function hapus_data($data){
    $idpesanan = $data['hapus'];

    $queryshow = "SELECT * FROM pesanan WHERE idpesanan = '$idpesanan';";
    $sqlshow = mysqli_query($GLOBALS['conn'] , $queryshow);
    $result = mysqli_fetch_assoc($sqlshow);

    $query="DELETE FROM pesanan WHERE idpesanan = '$idpesanan' ;";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    return true;

}

?>