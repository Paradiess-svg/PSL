<?php
include '../koneksi.php';
session_start();

$query = "SELECT * FROM menu;";
$sql = mysqli_query($conn, $query);
$no = 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../datatables/datatables.css">
    <script src="../datatables/datatables.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>

    <link rel="apple-touch-icon" sizes="180x180" href="asset/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="asset/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="asset/favicon-16x16.png">
<link rel="manifest" href="asset/site.webmanifest">

    <title>Waiter Entri menu</title>
</head>

<script>
    $(document).ready(function(){
        $('#dt').DataTable();
    });
</script>

<body>
    <nav class="navbar bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                Table Service
            </a>
            <div class="nav justify-content-end">
                <button class="btn btn-info"><h4>Waiter</h4></button> <a class="btn btn-danger m-2" href="../logout.php" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
            </div>
        </div>
    </nav>
    <a class="btn btn-primary mt-4" data-bs-toggle="offcanvas" href="#offcanvasExample" role="button" aria-controls="offcanvasExample">
    <i class="fa fa-arrow-right"></i>
</a>

<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel">Main Menu</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
  <ul class="list-group">
  <a href="indexPelanggan.php">
  <li class="list-group-item text-primary" aria-current="true"><i class="fa fa-users"></i> Pelanggan</li>
</a>
<a href="indexPesanan.php">
  <li class="list-group-item text-primary" aria-current="true"><i class="fa fa-users"></i> Pesanan</li>
</a>
    <li class="list-group-item active">  <i class="fa fa-cutlery" aria-hidden="true"></i> Menu  </li>
  <a href="indexCetak.php">
    <li class="list-group-item text-primary">  <i class="fa fa-cutlery" aria-hidden="true"></i> Generate Laporan  </li>
  </a>
</ul>

  </div>
</div>
    <div class="container">
        <h1 class="mt-3">Admin Entri menu</h1>

        <a href="kelolaMenu.php" type="button" class="btn btn-primary mb-3"> <i class="fa fa-plus"></i> Tambahkan data</a>
        
        <?php 
        if(isset($_SESSION['eksekusi'])):
        ?>

        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <strong>
                <?php
                echo $_SESSION['eksekusi'];
                ?>
            </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>

        <?php 

        session_destroy();
        endif;
        ?>

        <div class="table-responsive">
            <table id="dt" class="table align-middle table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">
                            <center>No</center>
                        </th>
                        <th scope="col">Nomor menu</th>
                        <th scope="col">namamenu</th>
                        <th scope="col">Foto </th>
                        <th scope="col">Status </th>
                        <th scope="col">harga </th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while (
                        $result = mysqli_fetch_assoc($sql)
                    ) {
                    ?>
                        <tr>
                            
                            <th scope="row">
                                <center><?php echo ++$no; ?>.</center>
                            </th>
                            <td><?php echo $result['idmenu']; ?></td>
                            <td><?php echo $result['namamenu']; ?></td>
                            <td><img style="width: 150px;" src="../imgMenu/<?php echo $result['foto']; ?>" alt=""></td>
                            <?php if($result['status']=='Tersedia'): ?>
                            <td class="fw-bolder bg-success text-white">
                                <?php echo $result['status']; ?> 
                            </td>
                            <?php else: ?>
                            <td class="fw-bolder bg-secondary text-warning">
                                <?php echo $result['status']; ?> 
                            </td>
                            <?php endif ?>
                            <td><?php echo $result['harga']; ?></td>
                            <td>
                                <?php if ($result['foto']=='default.jpg') {?>
                                <a href="kelolaMenuFoto.php?ubah=<?php echo $result['idmenu']; ?>" type="button" class="btn btn-success btn-sm"><i class="fa fa-camera"></i></a>
                                <?php
                                } else { ?>
                                    <a href="kelolaMenu.php?ubah=<?php echo $result['idmenu']; ?>" type="button" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></a>
                                    <?php
                                }
                                ?>
                                
                                <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $result['idmenu']?>"><i class="fa fa-trash"></i></button>

                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal<?= $result['idmenu']?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title text-danger fw-bold" id="exampleModalLabel">Konfirmasi</h5>
                                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <h4 class="text-warning"><b>Perhatian! data yang terhapus tak dapat di pulihkan</b></h4>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <a href="prosesMenu.php?hapus=<?php echo $result['idmenu']; ?>" type="button" class="btn btn-danger">Delete</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="m-5 align-middle align-center"></div>


</body>

</html>