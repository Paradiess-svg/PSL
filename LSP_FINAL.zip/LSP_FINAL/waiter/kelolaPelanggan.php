<!DOCTYPE html>

<?php
include '../koneksi.php';
session_start();


$idpelanggan = '';
$namapelanggan = '';
$jeniskelamin ='';
$nohp ='';
$alamat = '';

if (isset($_GET['ubah'])) {
    $idpelanggan = $_GET['ubah'];

    $query = "SELECT * FROM pelanggan WHERE idpelanggan = '$idpelanggan';";
    $sql = mysqli_query($conn, $query);

    $result = mysqli_fetch_assoc($sql);

    $idpelanggan = $result ['idpelanggan'];
    $namapelanggan = $result ['namapelanggan'];
    $jeniskelamin = $result ['jeniskelamin'];
    $nohp = $result ['nohp'];
    $alamat = $result ['alamat'];


    //var_dump($result);

    //die();
}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../datatables/datatables.css">
    <script src="../datatables/datatables.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>


    <link rel="apple-touch-icon" sizes="180x180" href="asset/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="asset/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="asset/favicon-16x16.png">
<link rel="manifest" href="asset/site.webmanifest">

    <title>Admin Entri pelanggan</title>
</head>

<body>
    <nav class="navbar bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                Table Service
            </a>
        </div>
    </nav>
    <div class="container">
        <h1 class="mt-3">Admin Entri pelanggan</h1>
<!-- ENTRI PESANAN BELUM -->
        <div class="container">
            <form method="post" action="prosesPelanggan.php" enctype="multipart/form-data">
                <input type="hidden" value="<?php echo $idpelanggan?>" name="idpelanggan">
                <div class="mb-3 row">
                    <label for="idpelanggan" class="col-sm-2 col-form-label">Nomor pelanggan</label>
                    <div class="col-sm-10">
                        <?php if (isset($_GET['ubah'])) { ?>
                            <input required type="text" name="idpelanggan" class="form-control" id="idpelanggan" value="<?php echo $idpelanggan ?>" disabled>
                        <?php
                        } else{
                        ?>
                        <input required type="text" name="idpelanggan" class="form-control" id="idpelanggan" placeholder="Ex: 10000000216*" value="<?php echo $idpelanggan ?>">
                    <?php } ?>
                    <p>Maximal 11 angka*</p>
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="nama" class="col-sm-2 col-form-label">namapelanggan</label>
                    <div class="col-sm-10">
                        <input required type="text" name="namapelanggan" class="form-control" id="nama" placeholder="Ex: Budi Hartono" value="<?php echo $namapelanggan ?>">
                    </div>
                </div>

                <div class="mb-3 row">
                    <label for="jkel" class="col-sm-2 col-form-label">jeniskelamin</label>
                    <div class="col-sm-10">
                        <select required id="jkel" name="jeniskelamin" class="form-select">
                            <option <?php if($jeniskelamin == 'Laki-laki') {echo "selected";} ?> value="Laki-laki">Laki-laki</option>
                            <option <?php if($jeniskelamin == 'Perempuan') {echo "selected";} ?> value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="nohp" class="col-sm-2 col-form-label">Nomor Telp</label>
                    <div class="col-sm-10">
                        <input required type="text" name="nohp" class="form-control" id="nohp" placeholder="Ex: 085774690939" value="<?php echo $nohp ?>">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="alamat" class="col-sm-2 col-form-label">alamat</label>
                    <div class="col-sm-10">
                        <textarea required class="form-control" name="alamat" id="alamat" rows="3"><?php echo $alamat ?></textarea>
                    </div>
                </div>
                <div class="mb-3 row mt-3">
                    <div class="col">
                        <?php
                        if (isset($_GET['ubah'])) {
                        ?>
                            <button type="submit" name="aksi" value="edit" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Simpan Perubahan</button>
                        <?php
                        } else {
                        ?>
                            <button type="submit" name="aksi" value="add" class="btn btn-primary"><i class="fa fa-floppy-o mx-1" aria-hidden="true"></i>Tambah</button>
                        <?php
                        }
                        ?>
                        <a href="indexPelanggan.php" type="button" class="btn btn-danger"><i class="fa fa-reply mx-1" aria-hidden="true"></i>Batal</a>
                    </div>
            </form>
        </div>



        <h6>Hello mom</h6>
</body>

</html>